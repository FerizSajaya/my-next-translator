(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_1mojsay._.js","static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_04pohm1._.js","static/chunks/1w5u_next_dist_compiled_next-devtools_index_0--rcrf.js","static/chunks/1w5u_next_dist_compiled_react-dom_1stxi2m._.js","static/chunks/1w5u_next_dist_compiled_react-server-dom-turbopack_1758a6p._.js","static/chunks/1w5u_next_dist_compiled_0nkjgnm._.js","static/chunks/1w5u_next_dist_client_0ver95_._.js","static/chunks/1w5u_next_dist_15o9uwi._.js","static/chunks/0zix_@swc_helpers_cjs_0hi-e47._.js"],
    source: "entry"
});
