(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__0h6wtd3._.css","static/chunks/1v-__@base-ui_react_01xu9c1._.js","static/chunks/1w5u_next_0is63go._.js","static/chunks/0yyv_@tanstack_query-core_build_modern_06e_hiv._.js","static/chunks/node_modules__pnpm_2065ltm._.js","static/chunks/_0l_cl4p._.js","static/chunks/src_app_error_tsx_0ts9uj7._.js"],
    source: "entry"
});
